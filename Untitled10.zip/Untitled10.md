

```python
import geopandas as gp
```


```python
tbl=gp.read_file("C:\\Users\SheuliMolla\Desktop\DEV LEAGUE\GEOSPATIAL DATA\spatial_OAHU\soilmu_a_hi990.shp")

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>AREASYMBOL</th>
      <th>SPATIALVER</th>
      <th>MUSYM</th>
      <th>MUKEY</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>HI990</td>
      <td>2</td>
      <td>KuD</td>
      <td>468440</td>
      <td>POLYGON ((-158.0759985289648 21.45443905267337...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>HI990</td>
      <td>2</td>
      <td>JaC</td>
      <td>468401</td>
      <td>POLYGON ((-157.7540751010808 21.4561554956124,...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>HI990</td>
      <td>2</td>
      <td>WaA</td>
      <td>468510</td>
      <td>POLYGON ((-157.9827233667245 21.45578937697503...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>HI990</td>
      <td>2</td>
      <td>KyB</td>
      <td>468442</td>
      <td>POLYGON ((-158.0655032115006 21.45632062218367...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>HI990</td>
      <td>2</td>
      <td>EwC</td>
      <td>468388</td>
      <td>POLYGON ((-158.121358371643 21.45617209560221,...</td>
    </tr>
    <tr>
      <th>5</th>
      <td>HI990</td>
      <td>2</td>
      <td>HLMG</td>
      <td>468393</td>
      <td>POLYGON ((-158.0700091556491 21.45676251675311...</td>
    </tr>
    <tr>
      <th>6</th>
      <td>HI990</td>
      <td>2</td>
      <td>LeC</td>
      <td>468450</td>
      <td>POLYGON ((-157.9912672080492 21.50241321087573...</td>
    </tr>
    <tr>
      <th>7</th>
      <td>HI990</td>
      <td>2</td>
      <td>KuB</td>
      <td>468438</td>
      <td>POLYGON ((-158.0501626518492 21.50222126593957...</td>
    </tr>
    <tr>
      <th>8</th>
      <td>HI990</td>
      <td>2</td>
      <td>KuD</td>
      <td>468440</td>
      <td>POLYGON ((-158.1162806141863 21.50239711860746...</td>
    </tr>
    <tr>
      <th>9</th>
      <td>HI990</td>
      <td>2</td>
      <td>HLMG</td>
      <td>468393</td>
      <td>POLYGON ((-158.032709517379 21.501053163789, -...</td>
    </tr>
    <tr>
      <th>10</th>
      <td>HI990</td>
      <td>2</td>
      <td>WaA</td>
      <td>468510</td>
      <td>POLYGON ((-158.0483082395996 21.50255302184401...</td>
    </tr>
    <tr>
      <th>11</th>
      <td>HI990</td>
      <td>2</td>
      <td>rST</td>
      <td>468534</td>
      <td>POLYGON ((-158.2236821329147 21.50261840228979...</td>
    </tr>
    <tr>
      <th>12</th>
      <td>HI990</td>
      <td>2</td>
      <td>rRK</td>
      <td>468531</td>
      <td>POLYGON ((-158.1746236904069 21.49978732961412...</td>
    </tr>
    <tr>
      <th>13</th>
      <td>HI990</td>
      <td>2</td>
      <td>LaC</td>
      <td>468447</td>
      <td>POLYGON ((-157.9769769018996 21.41882987797998...</td>
    </tr>
    <tr>
      <th>14</th>
      <td>HI990</td>
      <td>2</td>
      <td>LoB</td>
      <td>468451</td>
      <td>POLYGON ((-157.7917039808483 21.41779135790169...</td>
    </tr>
    <tr>
      <th>15</th>
      <td>HI990</td>
      <td>2</td>
      <td>LoD</td>
      <td>468453</td>
      <td>POLYGON ((-158.2016070485666 21.50088200723911...</td>
    </tr>
    <tr>
      <th>16</th>
      <td>HI990</td>
      <td>2</td>
      <td>MZ</td>
      <td>468461</td>
      <td>POLYGON ((-157.8535684608375 21.50262879172493...</td>
    </tr>
    <tr>
      <th>17</th>
      <td>HI990</td>
      <td>2</td>
      <td>KuC</td>
      <td>468439</td>
      <td>POLYGON ((-158.1057537822411 21.50124879764219...</td>
    </tr>
    <tr>
      <th>18</th>
      <td>HI990</td>
      <td>2</td>
      <td>KuD</td>
      <td>468440</td>
      <td>POLYGON ((-158.0518204243021 21.50325106664642...</td>
    </tr>
    <tr>
      <th>19</th>
      <td>HI990</td>
      <td>2</td>
      <td>WaA</td>
      <td>468510</td>
      <td>POLYGON ((-158.0184703396262 21.50365574355212...</td>
    </tr>
    <tr>
      <th>20</th>
      <td>HI990</td>
      <td>2</td>
      <td>KaeC</td>
      <td>468413</td>
      <td>POLYGON ((-157.9228871356843 21.62467986323746...</td>
    </tr>
    <tr>
      <th>21</th>
      <td>HI990</td>
      <td>2</td>
      <td>WaB</td>
      <td>468511</td>
      <td>POLYGON ((-158.0632407664691 21.62431256963097...</td>
    </tr>
    <tr>
      <th>22</th>
      <td>HI990</td>
      <td>2</td>
      <td>KaeB</td>
      <td>468412</td>
      <td>POLYGON ((-158.176747999487 21.56736340704765,...</td>
    </tr>
    <tr>
      <th>23</th>
      <td>HI990</td>
      <td>2</td>
      <td>WaC</td>
      <td>468512</td>
      <td>POLYGON ((-158.0484800677142 21.56582415296001...</td>
    </tr>
    <tr>
      <th>24</th>
      <td>HI990</td>
      <td>2</td>
      <td>PaC</td>
      <td>468491</td>
      <td>POLYGON ((-158.0054624630778 21.56847149149904...</td>
    </tr>
    <tr>
      <th>25</th>
      <td>HI990</td>
      <td>2</td>
      <td>LeB</td>
      <td>468449</td>
      <td>POLYGON ((-158.0499205819777 21.56839689439269...</td>
    </tr>
    <tr>
      <th>26</th>
      <td>HI990</td>
      <td>2</td>
      <td>W</td>
      <td>468509</td>
      <td>POLYGON ((-158.0590442830058 21.56799959120784...</td>
    </tr>
    <tr>
      <th>27</th>
      <td>HI990</td>
      <td>2</td>
      <td>LeC</td>
      <td>468450</td>
      <td>POLYGON ((-158.040859575959 21.5675768086675, ...</td>
    </tr>
    <tr>
      <th>28</th>
      <td>HI990</td>
      <td>2</td>
      <td>LaC3</td>
      <td>468448</td>
      <td>POLYGON ((-158.0816762612947 21.56898128080843...</td>
    </tr>
    <tr>
      <th>29</th>
      <td>HI990</td>
      <td>2</td>
      <td>rRK</td>
      <td>468531</td>
      <td>POLYGON ((-157.9148395032169 21.56899686895407...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>3976</th>
      <td>HI990</td>
      <td>2</td>
      <td>JaC</td>
      <td>468401</td>
      <td>POLYGON ((-157.8828360585289 21.30851112303182...</td>
    </tr>
    <tr>
      <th>3977</th>
      <td>HI990</td>
      <td>2</td>
      <td>MpD</td>
      <td>468476</td>
      <td>POLYGON ((-157.8075707574491 21.30093287559232...</td>
    </tr>
    <tr>
      <th>3978</th>
      <td>HI990</td>
      <td>2</td>
      <td>W</td>
      <td>468509</td>
      <td>POLYGON ((-158.0520732251109 21.30713883992365...</td>
    </tr>
    <tr>
      <th>3979</th>
      <td>HI990</td>
      <td>2</td>
      <td>CR</td>
      <td>468381</td>
      <td>POLYGON ((-158.0809165283568 21.30188422593811...</td>
    </tr>
    <tr>
      <th>3980</th>
      <td>HI990</td>
      <td>2</td>
      <td>KlA</td>
      <td>468420</td>
      <td>POLYGON ((-157.6857243697896 21.30285551503994...</td>
    </tr>
    <tr>
      <th>3981</th>
      <td>HI990</td>
      <td>2</td>
      <td>LPE</td>
      <td>468444</td>
      <td>POLYGON ((-157.6538992879474 21.30170803256969...</td>
    </tr>
    <tr>
      <th>3982</th>
      <td>HI990</td>
      <td>2</td>
      <td>KlB</td>
      <td>468421</td>
      <td>POLYGON ((-157.8328353225706 21.30510035815967...</td>
    </tr>
    <tr>
      <th>3983</th>
      <td>HI990</td>
      <td>2</td>
      <td>W</td>
      <td>468509</td>
      <td>POLYGON ((-158.1117369542491 21.30585054188164...</td>
    </tr>
    <tr>
      <th>3984</th>
      <td>HI990</td>
      <td>2</td>
      <td>LoB</td>
      <td>468451</td>
      <td>POLYGON ((-157.7977535367289 21.36330999334528...</td>
    </tr>
    <tr>
      <th>3985</th>
      <td>HI990</td>
      <td>2</td>
      <td>EmA</td>
      <td>468384</td>
      <td>POLYGON ((-157.7173450988588 21.36399663766, -...</td>
    </tr>
    <tr>
      <th>3986</th>
      <td>HI990</td>
      <td>2</td>
      <td>WzA</td>
      <td>468526</td>
      <td>POLYGON ((-158.0417130239251 21.36399647444994...</td>
    </tr>
    <tr>
      <th>3987</th>
      <td>HI990</td>
      <td>2</td>
      <td>WzB</td>
      <td>468527</td>
      <td>POLYGON ((-158.0375525832154 21.36393377802575...</td>
    </tr>
    <tr>
      <th>3988</th>
      <td>HI990</td>
      <td>2</td>
      <td>HLMG</td>
      <td>468393</td>
      <td>POLYGON ((-158.0769032730139 21.36276752010743...</td>
    </tr>
    <tr>
      <th>3989</th>
      <td>HI990</td>
      <td>2</td>
      <td>FL</td>
      <td>468389</td>
      <td>POLYGON ((-157.7153864163146 21.36090505685573...</td>
    </tr>
    <tr>
      <th>3990</th>
      <td>HI990</td>
      <td>2</td>
      <td>W</td>
      <td>468509</td>
      <td>POLYGON ((-158.0122814799307 21.36378340563541...</td>
    </tr>
    <tr>
      <th>3991</th>
      <td>HI990</td>
      <td>2</td>
      <td>W</td>
      <td>468509</td>
      <td>POLYGON ((-157.9898027236954 21.36284446395118...</td>
    </tr>
    <tr>
      <th>3992</th>
      <td>HI990</td>
      <td>2</td>
      <td>WkA</td>
      <td>468514</td>
      <td>POLYGON ((-158.0599538894056 21.36370981265592...</td>
    </tr>
    <tr>
      <th>3993</th>
      <td>HI990</td>
      <td>2</td>
      <td>AeE</td>
      <td>468379</td>
      <td>POLYGON ((-157.742140111132 21.36111695132261,...</td>
    </tr>
    <tr>
      <th>3994</th>
      <td>HI990</td>
      <td>2</td>
      <td>MdB</td>
      <td>468465</td>
      <td>POLYGON ((-157.9251993709373 21.35991079738518...</td>
    </tr>
    <tr>
      <th>3995</th>
      <td>HI990</td>
      <td>2</td>
      <td>KanE</td>
      <td>468415</td>
      <td>POLYGON ((-157.8517043277871 21.38645527896514...</td>
    </tr>
    <tr>
      <th>3996</th>
      <td>HI990</td>
      <td>2</td>
      <td>HnB</td>
      <td>468397</td>
      <td>POLYGON ((-157.9390905314438 21.38631681074406...</td>
    </tr>
    <tr>
      <th>3997</th>
      <td>HI990</td>
      <td>2</td>
      <td>HxA</td>
      <td>468399</td>
      <td>POLYGON ((-157.947344359469 21.38766847537533,...</td>
    </tr>
    <tr>
      <th>3998</th>
      <td>HI990</td>
      <td>2</td>
      <td>ALF</td>
      <td>468378</td>
      <td>POLYGON ((-157.7692716605779 21.3876496988243,...</td>
    </tr>
    <tr>
      <th>3999</th>
      <td>HI990</td>
      <td>2</td>
      <td>HLMG</td>
      <td>468393</td>
      <td>POLYGON ((-158.0341220356136 21.50225060220984...</td>
    </tr>
    <tr>
      <th>4000</th>
      <td>HI990</td>
      <td>2</td>
      <td>KuD</td>
      <td>468440</td>
      <td>POLYGON ((-158.1093303406209 21.50035947747706...</td>
    </tr>
    <tr>
      <th>4001</th>
      <td>HI990</td>
      <td>2</td>
      <td>WaC</td>
      <td>468512</td>
      <td>POLYGON ((-158.0306779114754 21.50024716028525...</td>
    </tr>
    <tr>
      <th>4002</th>
      <td>HI990</td>
      <td>2</td>
      <td>LoD</td>
      <td>468453</td>
      <td>POLYGON ((-158.1812760726532 21.49880530596061...</td>
    </tr>
    <tr>
      <th>4003</th>
      <td>HI990</td>
      <td>2</td>
      <td>W</td>
      <td>468509</td>
      <td>POLYGON ((-158.049298981081 21.49859106335092,...</td>
    </tr>
    <tr>
      <th>4004</th>
      <td>HI990</td>
      <td>2</td>
      <td>WaB</td>
      <td>468511</td>
      <td>POLYGON ((-158.0409351825925 21.49417195652572...</td>
    </tr>
    <tr>
      <th>4005</th>
      <td>HI990</td>
      <td>2</td>
      <td>MnC</td>
      <td>468470</td>
      <td>POLYGON ((-157.9255227455925 21.3345402860495,...</td>
    </tr>
  </tbody>
</table>
<p>4006 rows × 5 columns</p>
</div>




```python
type (tbl)
```




    geopandas.geodataframe.GeoDataFrame




```python
tbl.columns
```




    Index(['AREASYMBOL', 'SPATIALVER', 'MUSYM', 'MUKEY', 'geometry'], dtype='object')




```python
tbl.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>AREASYMBOL</th>
      <th>SPATIALVER</th>
      <th>MUSYM</th>
      <th>MUKEY</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>HI990</td>
      <td>2</td>
      <td>KuD</td>
      <td>468440</td>
      <td>POLYGON ((-158.0759985289648 21.45443905267337...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>HI990</td>
      <td>2</td>
      <td>JaC</td>
      <td>468401</td>
      <td>POLYGON ((-157.7540751010808 21.4561554956124,...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>HI990</td>
      <td>2</td>
      <td>WaA</td>
      <td>468510</td>
      <td>POLYGON ((-157.9827233667245 21.45578937697503...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>HI990</td>
      <td>2</td>
      <td>KyB</td>
      <td>468442</td>
      <td>POLYGON ((-158.0655032115006 21.45632062218367...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>HI990</td>
      <td>2</td>
      <td>EwC</td>
      <td>468388</td>
      <td>POLYGON ((-158.121358371643 21.45617209560221,...</td>
    </tr>
  </tbody>
</table>
</div>




```python
tbl.geometry[0]
```




![svg](output_5_0.svg)




```python
tbl.geometry [2]
```




![svg](output_6_0.svg)




```python
tbl.geometry [4]
```




![svg](output_7_0.svg)




```python
tbl.loc.[1]
```


      File "<ipython-input-34-b55b166984bd>", line 1
        tbl.loc.[1]
                ^
    SyntaxError: invalid syntax
    



```python
tbl.loc["geometry"]
```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    ~\AppData\Local\Continuum\anaconda3\lib\site-packages\pandas\core\indexing.py in _has_valid_type(self, key, axis)
       1505                 if not ax.contains(key):
    -> 1506                     error()
       1507             except TypeError as e:
    

    ~\AppData\Local\Continuum\anaconda3\lib\site-packages\pandas\core\indexing.py in error()
       1500                                .format(key=key,
    -> 1501                                        axis=self.obj._get_axis_name(axis)))
       1502 
    

    KeyError: 'the label [geometry] is not in the [index]'

    
    During handling of the above exception, another exception occurred:
    

    KeyError                                  Traceback (most recent call last)

    <ipython-input-35-e9ccc411b957> in <module>()
    ----> 1 tbl.loc["geometry"]
    

    ~\AppData\Local\Continuum\anaconda3\lib\site-packages\pandas\core\indexing.py in __getitem__(self, key)
       1371 
       1372             maybe_callable = com._apply_if_callable(key, self.obj)
    -> 1373             return self._getitem_axis(maybe_callable, axis=axis)
       1374 
       1375     def _is_scalar_access(self, key):
    

    ~\AppData\Local\Continuum\anaconda3\lib\site-packages\pandas\core\indexing.py in _getitem_axis(self, key, axis)
       1624 
       1625         # fall thru to straight lookup
    -> 1626         self._has_valid_type(key, axis)
       1627         return self._get_label(key, axis=axis)
       1628 
    

    ~\AppData\Local\Continuum\anaconda3\lib\site-packages\pandas\core\indexing.py in _has_valid_type(self, key, axis)
       1512                 raise
       1513             except:
    -> 1514                 error()
       1515 
       1516         return True
    

    ~\AppData\Local\Continuum\anaconda3\lib\site-packages\pandas\core\indexing.py in error()
       1499                 raise KeyError(u"the label [{key}] is not in the [{axis}]"
       1500                                .format(key=key,
    -> 1501                                        axis=self.obj._get_axis_name(axis)))
       1502 
       1503             try:
    

    KeyError: 'the label [geometry] is not in the [index]'



```python
tbl.index
```




    RangeIndex(start=0, stop=4006, step=1)




```python
tbl.columns
```




    Index(['AREASYMBOL', 'SPATIALVER', 'MUSYM', 'MUKEY', 'geometry'], dtype='object')




```python
tbl.columns.loc["geometry"]
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    <ipython-input-38-042007042ea8> in <module>()
    ----> 1 tbl.columns.loc["geometry"]
    

    AttributeError: 'Index' object has no attribute 'loc'



```python
tbl.head().geometry[2]
```




![svg](output_13_0.svg)


